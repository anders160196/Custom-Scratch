import unittest

from translator import english_to_french, french_to_english

class TestE2F(unittest.TestCase): 
    def test1(self): 
        self.assertEqual(english_to_french('Yes'), 'Oui') 
        self.assertEqual(english_to_french('No'), 'Non')
        self.assertIsNotNone(english_to_french('Thank you'))
        self.assertEqual(english_to_french('Hello'), 'Bonjour')

class TestF2E(unittest.TestCase): 
    def test1(self): 
        self.assertEqual(french_to_english('Oui'), 'Yes') 
        self.assertEqual(french_to_english('Non'), 'No')
        self.assertIsNotNone(french_to_english('Merci'))
        self.assertEqual(french_to_english('Bonjour'), 'Hello')

unittest.main()